library(testthat)
library(aweek)

test_check("aweek")
